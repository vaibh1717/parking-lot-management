# Simple-Parking-Lot-Management-System
This is a simple Parking Lot Management System using only HTML, CSS, Plain JavaScript. Here we can store inputted data into local storage &amp; display that data into a table plus we can also search for a particular entry.

LIVE_DEMO: https://soft-kulfi-4bb760.netlify.app/
